package com.studyfocus.app

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.TimeZone

class MainActivity : AppCompatActivity() {
    private lateinit var sp: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var tabBar: LinearLayout
    private var tab = 0
    private var mins = 180
    private var timer: CountDownTimer? = null
    private var game: Game? = null
    private var headImg: ImageView? = null
    private val tabNames = arrayOf("\uD83C\uDFE0 Home", "\u25B6 YouTube", "\uD83C\uDFAE Games", "\u2699 Apps")
    private val logoColors = intArrayOf(
        Color.parseColor("#E53935"), Color.parseColor("#1E88E5"), Color.parseColor("#8E24AA"),
        Color.parseColor("#F4511E"), Color.parseColor("#00897B"), Color.parseColor("#3949AB"), Color.parseColor("#6D4C41")
    )
    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            contentResolver.openInputStream(u)?.use { i ->
                File(filesDir, "bg.jpg").outputStream().use { o -> i.copyTo(o) }
            }
            loadBg()
            Toast.makeText(this, "Photo laga di", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        sp = getSharedPreferences("sf", 0)
        if (!sp.getBoolean("seeded", false)) {
            val d = listOf("Physics Wallah", "Vedantu", "Unacademy", "Khan Academy", "BYJU'S", "Magnet Brains", "StudyIQ",
                "Doubtnut", "Apni Kaksha", "LearnoHub", "Competition Wallah", "Eduncle", "Toppr")
                .map { "$it|https://www.youtube.com/results?search_query=${Uri.encode(it)}" }.toSet()
            sp.edit().putStringSet("chans", d).putBoolean("seeded", true).apply()
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        tabBar = LinearLayout(this).apply { setBackgroundColor(Color.WHITE) }
        tabNames.forEachIndexed { i, n ->
            val t = label(n, 13f, INK, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(14), 0, dp(14))
            t.setOnClickListener { game?.stop(); game = null; show(i) }
            tabBar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabBar, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        show(0)
    }

    override fun onResume() { super.onResume(); if (game == null) show(tab) }

    override fun onDestroy() { timer?.cancel(); game?.stop(); super.onDestroy() }

    private fun show(i: Int) {
        tab = i
        timer?.cancel()
        content.removeAllViews()
        val page = when (i) { 0 -> homePage(); 1 -> ytPage(); 2 -> gamesPage(); else -> appsPage() }
        content.addView(ScrollView(this).apply { addView(page) })
        for (k in 0 until tabBar.childCount) {
            tabBar.getChildAt(k).background = if (k == i) grad(Color.parseColor("#F9D423"), Color.parseColor("#FF8008"), 0) else null
        }
    }

    private fun body() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(12), dp(16), dp(24))
    }

    private fun locked() = sp.getLong("end", 0) > System.currentTimeMillis()

    private fun day(): Long {
        val n = System.currentTimeMillis()
        return (n + TimeZone.getDefault().getOffset(n)) / 86400000L
    }

    private fun settle() {
        if (sp.getBoolean("pending", false) && System.currentTimeMillis() >= sp.getLong("end", 0)) {
            val len = sp.getInt("len", 0)
            val today = day()
            val last = sp.getLong("lastDay", -10)
            var streak = sp.getInt("streak", 0)
            var days = sp.getInt("days", 0)
            if (today != last) {
                streak = if (today - last == 1L) streak + 1 else 1
                days++
            }
            sp.edit().putBoolean("pending", false)
                .putInt("points", sp.getInt("points", 0) + len)
                .putInt("totalMin", sp.getInt("totalMin", 0) + len)
                .putInt("streak", streak).putInt("days", days).putLong("lastDay", today).apply()
            Toast.makeText(this, "\uD83C\uDF89 Session poora! +$len points mile", Toast.LENGTH_LONG).show()
        }
    }

    private fun stat(v: String, l: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = rounded(Color.WHITE, 16)
        setPadding(dp(6), dp(12), dp(6), dp(12))
        addView(label(v, 21f, INK, true))
        addView(label(l, 12f, MUT))
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) }
    }

    // ---------- HOME ----------
    private fun homePage(): View {
        settle()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = FrameLayout(this)
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(INK, Color.parseColor("#2F7A6B"))))
        }
        headImg = img
        head.addView(img, FrameLayout.LayoutParams(-1, -1))
        head.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.parseColor("#CC000000"), Color.TRANSPARENT))
        }, FrameLayout.LayoutParams(-1, -1))
        head.addView(label("Study Focus\nPadhai pehle, baaki baad mein.", 22f, Color.WHITE, true).apply {
            setPadding(dp(20), 0, dp(20), dp(16))
        }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        head.setOnClickListener { pick.launch("image/*") }
        root.addView(head, LinearLayout.LayoutParams(-1, dp(180)))
        loadBg()

        val b = body()
        val pts = sp.getInt("points", 0)
        val lvl = pts / 300 + 1
        val titles = arrayOf("Shuruaati", "Focused", "Mehnati", "Scholar", "Topper", "Legend")
        val tm = sp.getInt("totalMin", 0)

        val stats = LinearLayout(this)
        stats.addView(stat("\u2B50 $pts", "Points"))
        stats.addView(stat("\uD83D\uDD25 ${sp.getInt("streak", 0)}", "Din streak"))
        stats.addView(stat("${sp.getInt("days", 0)}", "Total din"))
        b.addView(stats)

        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = (pts % 300) / 3
        }
        b.addView(card(
            label("Level $lvl \u00B7 ${titles[minOf(lvl - 1, 5)]}", 18f, INK, true),
            bar,
            label("Next level tak ${300 - pts % 300} points  |  Total padhai: ${tm / 60}h ${tm % 60}m", 13f, MUT)
        ))

        val clock = label("00:00:00", 50f, INK, true)
        clock.gravity = Gravity.CENTER
        val status = label("", 14f, MUT)
        status.gravity = Gravity.CENTER
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf(2, 3, 4, 5).forEach { h ->
            row.addView(Button(this).apply {
                text = "${h}h"; isAllCaps = false
                setOnClickListener { mins = h * 60; status.text = "Chuna: $h ghante  (${h * 60} points milenge)" }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val custom = EditText(this).apply {
            hint = "Ya apna time minute mein likho"; inputType = 2; gravity = Gravity.CENTER
        }
        b.addView(card(clock, status, row, custom, button("Focus shuru karo", ACC, INK) {
            custom.text.toString().toIntOrNull()?.let { if (it > 0) mins = it }
            startFocus()
        }))
        root.addView(b)

        val left = sp.getLong("end", 0) - System.currentTimeMillis()
        val n = sp.getStringSet("apps", emptySet())!!.size
        if (left > 0) {
            timer = object : CountDownTimer(left, 1000) {
                override fun onTick(m: Long) {
                    val s = m / 1000
                    clock.text = "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
                    status.text = "Focus ON \uD83D\uDD12  $n apps blocked"
                }
                override fun onFinish() { if (game == null) show(0) }
            }.start()
        } else {
            status.text = "Time chuno aur Focus shuru karo"
        }
        return root
    }

    private fun a11yOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    private fun startFocus() {
        if (locked()) { Toast.makeText(this, "\uD83D\uDD12 Focus chal raha hai", Toast.LENGTH_SHORT).show(); return }
        if (!a11yOn()) {
            Toast.makeText(this, "Accessibility mein 'Study Focus' ON karo, phir wapas aao", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        if (sp.getStringSet("apps", emptySet())!!.isEmpty() && sp.getStringSet("chans", emptySet())!!.isEmpty()) {
            Toast.makeText(this, "Pehle Apps tab mein block karne ke apps chuno", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this).setTitle("Pakka?")
            .setMessage("$mins minute ke liye lock lagega. Beech mein chune hue apps, Settings aur Play Store nahi khulenge. Poora karne par $mins points milenge.")
            .setPositiveButton("Lock lagao") { _, _ ->
                sp.edit().putLong("end", System.currentTimeMillis() + mins * 60000L)
                    .putInt("len", mins).putBoolean("pending", true).apply()
                show(0)
            }.setNegativeButton("Nahi", null).show()
    }

    private fun loadBg() {
        val f = File(filesDir, "bg.jpg")
        if (f.exists()) BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 4 })?.let { headImg?.setImageBitmap(it) }
    }

    // ---------- YOUTUBE ----------
    private fun openYt(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube")) }
        catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    private fun ytPage(): View {
        val b = body()
        b.addView(label("\u25B6 YouTube study channels", 22f, INK, true))
        b.addView(label("Focus ke time sirf ye channels khulenge. Kisi par tap karke kholo.", 14f, MUT))
        b.addView(button("\uD83D\uDD0D Study search") { studySearch() })
        b.addView(button("\u2795 Channel jodo", Color.WHITE, INK) { addChannel() })
        b.addView(button("\uD83D\uDD11 Study words jodo", Color.WHITE, INK) { addKeyword() })
        b.addView(label("Kisi bhi channel ya video par ye words dikhe to wo study maana jayega: PW, wallah, board, class 12, batch, JEE, NEET, NCERT, physics, chemistry... Tumhare jode hue: " +
            (sp.getStringSet("kwx", emptySet())!!.joinToString(", ").ifEmpty { "koi nahi" }), 13f, MUT).apply { setPadding(0, dp(10), 0, 0) })
        sp.getStringSet("chans", emptySet())!!.sorted().forEach { c ->
            val name = c.substringBefore("|")
            val url = c.substringAfter("|")
            val logo = label(name.take(1).uppercase(), 20f, Color.WHITE, true)
            logo.gravity = Gravity.CENTER
            logo.background = rounded(logoColors[(name.hashCode() and 0x7fffffff) % logoColors.size], 50)
            val r = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Color.WHITE, 16)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
                setOnClickListener { openYt(url) }
            }
            r.addView(logo, LinearLayout.LayoutParams(dp(46), dp(46)))
            val nm = label(name, 17f, INK, true)
            nm.setPadding(dp(12), 0, 0, 0)
            r.addView(nm, LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(label("\u25B6", 18f, MUT))
            b.addView(r)
        }
        return b
    }

    private fun addKeyword() {
        if (locked()) { Toast.makeText(this, "\uD83D\uDD12 Focus ke time list badal nahi sakte", Toast.LENGTH_SHORT).show(); return }
        val e = EditText(this).apply { hint = "Word, jaise up board ya mera teacher ka naam" }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(10), dp(20), 0); addView(e, -1, -2) }
        AlertDialog.Builder(this).setTitle("Study word").setView(box)
            .setPositiveButton("Jodo") { _, _ ->
                val w = e.text.toString().trim().lowercase()
                if (w.isNotEmpty()) {
                    val set = sp.getStringSet("kwx", emptySet())!!.toMutableSet()
                    set.add(w)
                    sp.edit().putStringSet("kwx", set).apply(); show(1)
                }
            }
            .setNeutralButton("Mere words hatao") { _, _ -> sp.edit().remove("kwx").apply(); show(1) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun addChannel() {
        if (locked()) { Toast.makeText(this, "\uD83D\uDD12 Focus ke time list badal nahi sakte", Toast.LENGTH_SHORT).show(); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = EditText(this).apply { hint = "Channel ka naam (jaisa YouTube par dikhta hai)" }
        val u = EditText(this).apply { hint = "Link, jaise https://youtube.com/@PhysicsWallah" }
        box.addView(n); box.addView(u)
        AlertDialog.Builder(this).setTitle("Study channel").setView(box)
            .setPositiveButton("Jodo") { _, _ ->
                if (n.text.isNotBlank() && u.text.isNotBlank()) {
                    val set = sp.getStringSet("chans", emptySet())!!.toMutableSet()
                    set.add("${n.text.toString().trim()}|${u.text.toString().trim()}")
                    sp.edit().putStringSet("chans", set).apply(); show(1)
                }
            }
            .setNeutralButton("Sab hatao") { _, _ -> sp.edit().remove("chans").apply(); show(1) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun studySearch() {
        val q = EditText(this).apply { hint = "Kya padhna hai? jaise class 12 physics" }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(10), dp(20), 0); addView(q, -1, -2) }
        AlertDialog.Builder(this).setTitle("Study search").setView(box).setPositiveButton("Dhundo") { _, _ ->
            val items = (listOf("Sab study channels") + sp.getStringSet("chans", emptySet())!!.map { it.substringBefore("|") }).toTypedArray()
            AlertDialog.Builder(this).setTitle("Kis channel se?").setItems(items) { _, w ->
                val extra = if (w == 0) "" else " " + items[w]
                openYt("https://www.youtube.com/results?search_query=" + Uri.encode(q.text.toString() + extra))
            }.show()
        }.setNegativeButton("Cancel", null).show()
    }

    // ---------- GAMES ----------
    private class GI(val key: String, val em: String, val title: String, val desc: String, val a: String, val b: String)

    private val gi = listOf(
        GI("seq", "\uD83E\uDDE9", "Pattern Yaad Rakho", "Jo pattern chamke wahi dohrao. Memory strong hoti hai.", "#7B2FF7", "#F107A3"),
        GI("mul", "\u2716\uFE0F", "Multiply Master", "Pahade aur guna ke sawal. 10 mein 8 sahi to level up.", "#4776E6", "#8E54E9"),
        GI("math", "\u2795", "Tez Hisaab", "30 second mein jitne sawal ho sake.", "#C0392B", "#F39C12"),
        GI("tf", "\u2705", "Sahi ya Galat", "Jawab sahi hai ya galat? Jaldi batao.", "#00B09B", "#96C93D"),
        GI("match", "\uD83C\uDCCF", "Card Match", "Jode milao. Level ke saath cards badhte hain.", "#EE0979", "#FF6A00"),
        GI("ord", "\uD83D\uDD22", "Number Order", "1 se shuru karke order mein tap karo, jaldi!", "#134E5E", "#3A9D6B"),
        GI("stroop", "\uD83C\uDF08", "Rang Pehchano", "Shabd nahi, uska rang batao. Dimag ghoom jayega!", "#FF512F", "#DD2476"),
        GI("num", "\uD83E\uDDEE", "Number Yaad Rakho", "Number dekho, chhupne ke baad likho.", "#0F8B7D", "#2BBF6B"),
        GI("odd", "\uD83C\uDFA8", "Alag Rang Pehchano", "Ek dabba thoda alag hai. Focus badhta hai.", "#2193B0", "#5B5FC7"),
        GI("react", "\u26A1", "Reflex Test", "Hara hote hi tap karo.", "#B71C2E", "#EF473A")
    )

    private fun make(key: String): Game = when (key) {
        "seq" -> SeqGame(this)
        "mul" -> MulGame(this)
        "math" -> MathGame(this)
        "tf" -> TfGame(this)
        "match" -> MatchGame(this)
        "ord" -> OrdGame(this)
        "stroop" -> StroopGame(this)
        "num" -> NumGame(this)
        "odd" -> OddGame(this)
        else -> ReactGame(this)
    }

    private fun gamesPage(): View {
        val b = body()
        b.addView(label("Brain Games", 30f, Color.parseColor("#7B2FF7"), true))
        b.addView(label("Dimag ke games. Padhai ke beech 5 minute ka break lo, level clear karo.", 14f, MUT))
        gi.forEach { g ->
            val bst = sp.getInt("best_${g.key}", 0)
            val bt = when {
                bst == 0 -> "Abhi khela nahi"
                g.key == "react" -> "Best: $bst ms"
                g.key == "math" || g.key == "tf" || g.key == "stroop" -> "Best score: $bst"
                else -> "Best level: $bst"
            }
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = grad(Color.parseColor(g.a), Color.parseColor(g.b))
                setPadding(dp(14), dp(14), dp(14), dp(14))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
                setOnClickListener { openGame(g) }
            }
            row.addView(label(g.em, 34f, Color.WHITE))
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(8), 0)
                addView(label(g.title, 18f, Color.WHITE, true))
                addView(label(g.desc, 13f, Color.WHITE))
                addView(label(bt, 12f, Color.WHITE, true))
            }
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label("\u25B6", 22f, Color.WHITE, true))
            b.addView(row)
        }
        return b
    }

    private fun openGame(g: GI) {
        val gm = make(g.key)
        gm.c1 = Color.parseColor(g.a)
        gm.c2 = Color.parseColor(g.b)
        game = gm
        content.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
        col.addView(button("\u2190 Wapas", Color.WHITE, INK) { gm.stop(); game = null; show(2) })
        val head = label(g.em + "  " + g.title, 22f, Color.WHITE, true)
        head.background = grad(gm.c1, gm.c2)
        head.setPadding(dp(18), dp(18), dp(18), dp(18))
        head.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        col.addView(head)
        col.addView(card(gm.build()))
        content.addView(ScrollView(this).apply { addView(col) })
    }

    // ---------- APPS ----------
    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun appsPage(): View {
        val b = body()
        b.addView(label("\u2699 Block hone wale apps", 22f, INK, true))
        val sel = sp.getStringSet("apps", emptySet())!!
        b.addView(card(*(
            if (sel.isEmpty()) listOf(label("Abhi koi app nahi chuna", 15f, MUT))
            else sel.map { label("\uD83D\uDD12 " + appLabel(it), 16f, INK) }
        ).toTypedArray()))
        b.addView(button("Apps chuno") { pickApps() })
        b.addView(button("\uD83D\uDDBC Home ki photo badlo", Color.WHITE, INK) { pick.launch("image/*") })
        val on = a11yOn()
        b.addView(card(
            label(if (on) "\u2705 Accessibility ON hai" else "\u26A0 Accessibility OFF hai", 16f, INK, true),
            label("Blocking ke liye Accessibility mein Study Focus ON hona zaroori hai.", 13f, MUT),
            button("Accessibility kholo", Color.WHITE, INK) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        ))
        return b
    }

    private fun pickApps() {
        if (locked()) { Toast.makeText(this, "\uD83D\uDD12 Focus ke time list badal nahi sakte", Toast.LENGTH_SHORT).show(); return }
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val sel = sp.getStringSet("apps", emptySet())!!.toMutableSet()
        AlertDialog.Builder(this).setTitle("Kya block karna hai?")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), BooleanArray(apps.size) { apps[it].first in sel }) { _, w, c ->
                if (c) sel.add(apps[w].first) else sel.remove(apps[w].first)
            }
            .setPositiveButton("Save") { _, _ -> sp.edit().putStringSet("apps", sel).apply(); show(3) }.show()
    }
}
