package com.studyfocus.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var sp: SharedPreferences
    private lateinit var img: ImageView
    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var chBox: LinearLayout
    private var mins = 180
    private var timer: CountDownTimer? = null
    private val ink = Color.parseColor("#12332F")
    private val acc = Color.parseColor("#E8D44D")

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            contentResolver.openInputStream(u)?.use { i ->
                File(filesDir, "bg.jpg").outputStream().use { o -> i.copyTo(o) }
            }
            loadBg()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, bg: Int, fg: Int, click: () -> Unit) = Button(this).apply {
        text = t; setTextColor(fg); isAllCaps = false; textSize = 16f
        background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(14).toFloat() }
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        sp = getSharedPreferences("sf", 0)
        if (!sp.getBoolean("seeded", false)) {
            val d = listOf("Physics Wallah", "Vedantu", "Unacademy", "Khan Academy", "BYJU'S", "Magnet Brains", "StudyIQ",
                "Doubtnut", "Apni Kaksha", "LearnoHub", "Competition Wallah", "Eduncle", "Toppr")
                .map { "$it|https://www.youtube.com/results?search_query=${Uri.encode(it)}" }.toSet()
            sp.edit().putStringSet("chans", d).putBoolean("seeded", true).apply()
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#EEF2EF")) }

        val head = FrameLayout(this)
        img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ink, Color.parseColor("#2F7A6B"))))
        }
        head.addView(img, FrameLayout.LayoutParams(-1, -1))
        head.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.parseColor("#CC000000"), Color.TRANSPARENT))
        }, FrameLayout.LayoutParams(-1, -1))
        head.addView(TextView(this).apply {
            text = "Study Focus\nPadhai pehle, baaki baad mein."
            setTextColor(Color.WHITE); textSize = 22f; setPadding(dp(20), 0, dp(20), dp(18))
        }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        head.setOnClickListener { pick.launch("image/*") }
        root.addView(head, LinearLayout.LayoutParams(-1, dp(220)))

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(30)) }
        clock = TextView(this).apply { textSize = 52f; setTextColor(ink); gravity = Gravity.CENTER; text = "00:00:00"; setPadding(0, dp(10), 0, 0) }
        status = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(Color.parseColor("#5B716D")) }
        body.addView(clock); body.addView(status)

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        listOf(2, 3, 4, 5).forEach { h ->
            row.addView(Button(this).apply {
                text = "${h}h"; isAllCaps = false
                setOnClickListener { mins = h * 60; status.text = "Chuna gaya: $h ghante" }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        body.addView(row)
        val custom = EditText(this).apply { hint = "Ya apna time minute mein likho"; inputType = 2; gravity = Gravity.CENTER }
        body.addView(custom)

        body.addView(btn("Block hone wale apps chuno", Color.WHITE, ink) { pickApps() })
        body.addView(btn("Study channels jodo (YouTube)", Color.WHITE, ink) { addChannel() })
        body.addView(btn("Study search (YouTube)", Color.WHITE, ink) { studySearch() })
        body.addView(btn("Focus shuru karo", acc, ink) {
            custom.text.toString().toIntOrNull()?.let { if (it > 0) mins = it }
            startFocus()
        })
        body.addView(btn("Strict lock (beech mein nahi ruk sakte)", Color.parseColor("#DDE6E2"), Color.parseColor("#B3402F")) { stopFocus() })
        chBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(chBox)
        root.addView(body)
        setContentView(ScrollView(this).apply { addView(root) })
        loadBg()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun loadBg() {
        val f = File(filesDir, "bg.jpg")
        if (f.exists()) BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 4 })?.let { img.setImageBitmap(it) }
    }

    private fun a11yOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    private fun startFocus() {
        if (!a11yOn()) {
            Toast.makeText(this, "Accessibility mein 'Study Focus' ON karo, phir wapas aao", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        if (sp.getStringSet("apps", emptySet())!!.isEmpty() && sp.getStringSet("chans", emptySet())!!.isEmpty()) {
            Toast.makeText(this, "Pehle block karne ke apps chuno", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this).setTitle("Pakka?")
            .setMessage("$mins minute ke liye lock lagega. Beech mein khol nahi paoge: chune hue apps, Settings aur Play Store sab band.")
            .setPositiveButton("Lock lagao") { _, _ ->
                sp.edit().putLong("end", System.currentTimeMillis() + mins * 60000L).apply(); refresh()
            }.setNegativeButton("Nahi", null).show()
    }

    private fun stopFocus() {
        Toast.makeText(this, if (locked()) "\uD83D\uDD12 Strict mode: time khatam hone tak lock hata nahi sakte" else "Focus abhi band hi hai", Toast.LENGTH_LONG).show()
    }

    private fun refresh() {
        timer?.cancel()
        val left = sp.getLong("end", 0) - System.currentTimeMillis()
        val n = sp.getStringSet("apps", emptySet())!!.size
        if (left > 0) {
            timer = object : CountDownTimer(left, 1000) {
                override fun onTick(m: Long) {
                    val s = m / 1000
                    clock.text = "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
                    status.text = "Focus ON. $n apps blocked."
                }
                override fun onFinish() { refresh() }
            }.start()
        } else {
            clock.text = "00:00:00"
            status.text = "Focus band. Sab apps normal. ($n apps list mein)"
        }
        chBox.removeAllViews()
        sp.getStringSet("chans", emptySet())!!.forEach { c ->
            val (name, url) = (c + "|").split("|")
            chBox.addView(btn("\u25B6  $name kholo", Color.WHITE, ink) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube"))
            })
        }
    }

    private fun locked() = sp.getLong("end", 0) > System.currentTimeMillis()

    private fun pickApps() {
        if (locked()) { Toast.makeText(this, "\uD83D\uDD12 Focus ke time list badal nahi sakte", Toast.LENGTH_SHORT).show(); return }
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val sel = sp.getStringSet("apps", emptySet())!!.toMutableSet()
        AlertDialog.Builder(this).setTitle("Kya block karna hai?")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), BooleanArray(apps.size) { apps[it].first in sel }) { _, w, c ->
                if (c) sel.add(apps[w].first) else sel.remove(apps[w].first)
            }
            .setPositiveButton("Save") { _, _ -> sp.edit().putStringSet("apps", sel).apply(); refresh() }.show()
    }

    private fun addChannel() {
        if (locked()) { Toast.makeText(this, "\uD83D\uDD12 Focus ke time list badal nahi sakte", Toast.LENGTH_SHORT).show(); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = EditText(this).apply { hint = "Channel ka naam (jaisa YouTube par dikhta hai)" }
        val u = EditText(this).apply { hint = "Link, jaise https://youtube.com/@PhysicsWallah" }
        box.addView(n); box.addView(u)
        AlertDialog.Builder(this).setTitle("Study channel").setView(box)
            .setPositiveButton("Jodo") { _, _ ->
                if (n.text.isNotBlank() && u.text.isNotBlank()) {
                    val set = sp.getStringSet("chans", emptySet())!!.toMutableSet()
                    set.add("${n.text.toString().trim()}|${u.text.toString().trim()}")
                    sp.edit().putStringSet("chans", set).apply(); refresh()
                }
            }
            .setNeutralButton("Sab hatao") { _, _ -> sp.edit().remove("chans").apply(); refresh() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun studySearch() {
        val q = EditText(this).apply { hint = "Kya padhna hai? jaise class 12 physics" }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(10), dp(20), 0); addView(q, -1, -2) }
        AlertDialog.Builder(this).setTitle("Study search").setView(box).setPositiveButton("Dhundo") { _, _ ->
            val items = (listOf("Sab study channels") + sp.getStringSet("chans", emptySet())!!.map { it.substringBefore("|") }).toTypedArray()
            AlertDialog.Builder(this).setTitle("Kis channel se?").setItems(items) { _, w ->
                val extra = if (w == 0) "" else " " + items[w]
                val url = "https://www.youtube.com/results?search_query=" + Uri.encode(q.text.toString() + extra)
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube")) }
                catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            }.show()
        }.setNegativeButton("Cancel", null).show()
    }
}
