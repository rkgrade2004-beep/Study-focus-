package com.studyfocus.app

import android.content.Context
import android.graphics.Color
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

abstract class Game(val ctx: Context, val key: String, val title: String) {
    var alive = true
    var c1 = INK
    var c2 = ACC
    protected val handler = Handler(Looper.getMainLooper())
    private val sp = ctx.getSharedPreferences("sf", 0)
    var best: Int
        get() = sp.getInt("best_$key", 0)
        set(v) { sp.edit().putInt("best_$key", v).apply() }

    protected fun later(ms: Long, f: () -> Unit) {
        handler.postDelayed({ if (alive) f() }, ms)
    }

    protected fun btn(t: String, f: () -> Unit) = ctx.button(t, c1, Color.WHITE, f)

    open fun stop() { alive = false; handler.removeCallbacksAndMessages(null) }
    abstract fun build(): View

    protected fun col() = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
    }
}

class SeqGame(ctx: Context) : Game(ctx, "seq", "Pattern yaad rakho") {
    private val cells = ArrayList<View>()
    private val seq = ArrayList<Int>()
    private var idx = 0
    private var input = false
    private lateinit var info: TextView
    private val off = Color.parseColor("#C9D8D3")

    override fun build(): View {
        val root = col()
        info = ctx.label("Taiyaar ho jao...", 18f, INK, true)
        info.gravity = Gravity.CENTER
        root.addView(info)
        for (r in 0 until 3) {
            val row = LinearLayout(ctx)
            for (c in 0 until 3) {
                val i = r * 3 + c
                val v = View(ctx)
                v.background = ctx.rounded(off, 14)
                v.layoutParams = LinearLayout.LayoutParams(ctx.dp(96), ctx.dp(96)).apply {
                    setMargins(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
                }
                v.setOnClickListener { tap(i) }
                cells.add(v); row.addView(v)
            }
            root.addView(row)
        }
        later(800) { next() }
        return root
    }

    private fun flash(i: Int, color: Int = c2) {
        cells[i].background = ctx.rounded(color, 14)
        later(350) { cells[i].background = ctx.rounded(off, 14) }
    }

    private fun next() {
        seq.add(Random.nextInt(9)); input = false
        info.text = "Level ${seq.size}: dhyan se dekho"
        seq.forEachIndexed { k, c -> later(500L + 600L * k) { flash(c) } }
        later(600L * seq.size + 700L) { input = true; idx = 0; info.text = "Ab tum dohrao" }
    }

    private fun tap(i: Int) {
        if (!input) return
        if (i == seq[idx]) {
            flash(i, Color.parseColor("#4CAF50")); idx++
            if (idx == seq.size) {
                input = false
                if (seq.size > best) best = seq.size
                info.text = "Level ${seq.size} clear! \uD83C\uDF89"
                later(1000) { next() }
            }
        } else {
            input = false
            flash(i, Color.parseColor("#E53935"))
            info.text = "Galat! Level ${seq.size} tak pahunche. Dobara..."
            seq.clear()
            later(1500) { next() }
        }
    }
}

class MathGame(ctx: Context) : Game(ctx, "math", "Tez hisaab") {
    private var score = 0
    private var answer = 0
    private var timer: CountDownTimer? = null
    private lateinit var info: TextView
    private lateinit var q: TextView
    private lateinit var area: LinearLayout

    override fun build(): View {
        val root = col()
        info = ctx.label("", 18f, INK, true)
        q = ctx.label("", 38f, INK, true)
        q.gravity = Gravity.CENTER
        q.setPadding(0, ctx.dp(20), 0, ctx.dp(20))
        area = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(info); root.addView(q); root.addView(area)
        start()
        return root
    }

    private fun start() {
        score = 0
        ask()
        timer?.cancel()
        timer = object : CountDownTimer(30000, 1000) {
            override fun onTick(m: Long) { info.text = "Score $score   |   ${m / 1000}s" }
            override fun onFinish() {
                if (!alive) return
                if (score > best) best = score
                q.text = "Time up!\nScore: $score"
                area.removeAllViews()
                area.addView(btn("Dobara khelo") { start() })
            }
        }.start()
    }

    private fun ask() {
        val lvl = score / 4 + 1
        val max = 8 + lvl * 6
        val a = Random.nextInt(2, max)
        val b = Random.nextInt(2, max)
        val pair: Pair<String, Int> = when (Random.nextInt(if (lvl > 2) 3 else 2)) {
            0 -> Pair("$a + $b", a + b)
            1 -> Pair("${a + b} - $b", a)
            else -> {
                val x = Random.nextInt(2, 6 + lvl)
                val y = Random.nextInt(2, 10)
                Pair("$x \u00D7 $y", x * y)
            }
        }
        answer = pair.second
        q.text = "${pair.first} = ?"
        val opts = HashSet<Int>()
        opts.add(answer)
        while (opts.size < 4) opts.add(answer + Random.nextInt(-9, 10))
        val list = opts.shuffled()
        area.removeAllViews()
        for (r in 0 until 2) {
            val row = LinearLayout(ctx)
            for (c in 0 until 2) {
                val v = list[r * 2 + c]
                val b = ctx.button("$v", Color.WHITE, INK) { pick(v) }
                b.layoutParams = LinearLayout.LayoutParams(0, ctx.dp(64), 1f).apply {
                    setMargins(ctx.dp(4), ctx.dp(6), ctx.dp(4), 0)
                }
                row.addView(b)
            }
            area.addView(row)
        }
    }

    private fun pick(v: Int) {
        if (v == answer) score++ else score = maxOf(0, score - 1)
        ask()
    }

    override fun stop() { timer?.cancel(); super.stop() }
}

class NumGame(ctx: Context) : Game(ctx, "num", "Number yaad rakho") {
    private var level = 3
    private lateinit var area: LinearLayout
    private lateinit var info: TextView

    override fun build(): View {
        val root = col()
        info = ctx.label("", 18f, INK, true)
        area = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(info); root.addView(area)
        later(300) { show() }
        return root
    }

    private fun show() {
        val n = (1..level).joinToString("") { Random.nextInt(10).toString() }
        info.text = "Level ${level - 2}: ye number yaad karo"
        area.removeAllViews()
        val t = ctx.label(n, 44f, INK, true)
        t.setPadding(0, ctx.dp(30), 0, ctx.dp(30))
        area.addView(t)
        later(900L + level * 450L) { ask(n) }
    }

    private fun ask(n: String) {
        info.text = "Ab number likho"
        area.removeAllViews()
        val e = EditText(ctx)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.gravity = Gravity.CENTER
        e.textSize = 28f
        e.hint = "?"
        area.addView(e, LinearLayout.LayoutParams(-1, -2))
        area.addView(btn("Check") {
            if (e.text.toString() == n) {
                if (level - 2 > best) best = level - 2
                level++
                info.text = "Sahi! \uD83C\uDF89"
                later(900) { show() }
            } else {
                info.text = "Galat. Number tha $n"
                level = maxOf(3, level - 1)
                later(1800) { show() }
            }
        })
    }
}

class OddGame(ctx: Context) : Game(ctx, "odd", "Alag rang pehchano") {
    private var level = 1
    private lateinit var info: TextView
    private lateinit var area: LinearLayout

    override fun build(): View {
        val root = col()
        info = ctx.label("", 18f, INK, true)
        info.gravity = Gravity.CENTER
        area = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, ctx.dp(16), 0, 0)
        }
        root.addView(info); root.addView(area)
        round()
        return root
    }

    private fun round() {
        info.text = "Level $level: alag rang wala dabba dabao"
        area.removeAllViews()
        val n = minOf(7, 2 + level / 2)
        val hue = Random.nextFloat() * 360f
        val diff = maxOf(0.05f, 0.30f - level * 0.02f)
        val base = Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.9f))
        val odd = Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.9f - diff))
        val oddIdx = Random.nextInt(n * n)
        val size = (ctx.resources.displayMetrics.widthPixels - ctx.dp(64)) / n
        for (r in 0 until n) {
            val row = LinearLayout(ctx)
            for (c in 0 until n) {
                val i = r * n + c
                val v = View(ctx)
                v.background = ctx.rounded(if (i == oddIdx) odd else base, 8)
                v.layoutParams = LinearLayout.LayoutParams(size - ctx.dp(4), size - ctx.dp(4)).apply {
                    setMargins(ctx.dp(2), ctx.dp(2), ctx.dp(2), ctx.dp(2))
                }
                v.setOnClickListener {
                    if (i == oddIdx) {
                        if (level > best) best = level
                        level++
                        round()
                    } else {
                        info.text = "Galat! Level $level dobara"
                        later(600) { round() }
                    }
                }
                row.addView(v)
            }
            area.addView(row)
        }
    }
}

class ReactGame(ctx: Context) : Game(ctx, "react", "Reflex test") {
    private lateinit var pad: TextView
    private lateinit var info: TextView
    private var state = 0
    private var t0 = 0L
    private var token = 0

    override fun build(): View {
        val root = col()
        info = ctx.label(if (best > 0) "Best: $best ms" else "Hara hote hi tap karo", 18f, INK, true)
        pad = ctx.label("Shuru karne ke liye tap karo", 22f, Color.WHITE, true)
        pad.gravity = Gravity.CENTER
        pad.background = ctx.rounded(INK, 20)
        pad.layoutParams = LinearLayout.LayoutParams(-1, ctx.dp(300)).apply { topMargin = ctx.dp(16) }
        pad.setOnClickListener { tap() }
        root.addView(info); root.addView(pad)
        return root
    }

    private fun tap() {
        when (state) {
            0 -> {
                state = 1; token++
                val my = token
                pad.text = "Ruko..."
                pad.background = ctx.rounded(Color.parseColor("#C62828"), 20)
                later(1500L + Random.nextLong(2500L)) {
                    if (state == 1 && my == token) {
                        state = 2
                        t0 = System.nanoTime()
                        pad.text = "ABHI TAP KARO!"
                        pad.background = ctx.rounded(Color.parseColor("#2E7D32"), 20)
                    }
                }
            }
            1 -> {
                token++; state = 0
                pad.text = "Bahut jaldi! Dobara tap karo"
                pad.background = ctx.rounded(INK, 20)
            }
            else -> {
                val ms = ((System.nanoTime() - t0) / 1_000_000L).toInt()
                state = 0
                if (best == 0 || ms < best) best = ms
                pad.text = "$ms ms\nDobara tap karo"
                pad.background = ctx.rounded(INK, 20)
                info.text = "Best: $best ms"
            }
        }
    }
}

class MulGame(ctx: Context) : Game(ctx, "mul", "Multiply Master") {
    private var lv = 1
    private var q = 0
    private var ok = 0
    private var a = 2
    private var b = 2
    private var busy = false
    private lateinit var info: TextView
    private lateinit var ques: TextView
    private lateinit var e: EditText
    private lateinit var fb: TextView

    override fun build(): View {
        lv = minOf(best + 1, 10)
        val root = col()
        info = ctx.label("", 17f, INK, true)
        ques = ctx.label("", 38f, INK, true)
        ques.gravity = Gravity.CENTER
        ques.setPadding(0, ctx.dp(16), 0, ctx.dp(16))
        e = EditText(ctx)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.gravity = Gravity.CENTER
        e.textSize = 28f
        e.hint = "?"
        fb = ctx.label("", 16f, MUT)
        fb.gravity = Gravity.CENTER
        root.addView(info); root.addView(ques)
        root.addView(e, LinearLayout.LayoutParams(-1, -2))
        root.addView(btn("Check") { chk() })
        root.addView(fb)
        nx()
        return root
    }

    private fun nx() {
        busy = false
        if (q >= 10) {
            busy = true
            if (ok >= 8) {
                if (lv > best) best = lv
                fb.text = "Level $lv clear! $ok/10 \uD83C\uDF89"
                lv = minOf(lv + 1, 10)
            } else fb.text = "$ok/10. 8 sahi chahiye, dobara!"
            q = 0; ok = 0
            later(1600) { nx() }
            return
        }
        val m = 3 + lv
        a = Random.nextInt(2, m + 1)
        b = Random.nextInt(2, 11)
        ques.text = "$a \u00D7 $b = ?"
        info.text = "Level $lv  \u00B7  Sawal ${q + 1}/10  \u00B7  Sahi $ok"
        e.setText("")
    }

    private fun chk() {
        if (busy) return
        val t = e.text.toString().toIntOrNull() ?: return
        if (t == a * b) { ok++; fb.text = "\u2705 Sahi!" } else fb.text = "\u274C $a \u00D7 $b = ${a * b}"
        q++
        nx()
    }
}

class MatchGame(ctx: Context) : Game(ctx, "match", "Card Match") {
    private var lv = 1
    private val em = listOf("\uD83D\uDC36", "\uD83D\uDC31", "\uD83E\uDD8A", "\uD83D\uDC3C", "\uD83D\uDC38", "\uD83E\uDD81",
        "\uD83D\uDC35", "\uD83D\uDC2F", "\uD83D\uDC19", "\uD83E\uDD84", "\uD83C\uDF4E", "\uD83D\uDE80")
    private val op = ArrayList<TextView>()
    private var lock = false
    private var found = 0
    private var mv = 0
    private var p = 0
    private val off = Color.parseColor("#C9D8D3")
    private lateinit var info: TextView
    private lateinit var area: LinearLayout

    override fun build(): View {
        val root = col()
        info = ctx.label("", 17f, INK, true)
        info.gravity = Gravity.CENTER
        area = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, ctx.dp(12), 0, 0) }
        root.addView(info); root.addView(area)
        round()
        return root
    }

    private fun round() {
        p = minOf(12, 2 + lv * 2)
        found = 0; mv = 0; lock = false
        op.clear()
        info.text = "Level $lv  \u00B7  Chaal 0"
        area.removeAllViews()
        val d = (em.take(p) + em.take(p)).shuffled()
        val size = (ctx.resources.displayMetrics.widthPixels - ctx.dp(64)) / 4
        for (r in 0 until d.size / 4) {
            val row = LinearLayout(ctx)
            for (c in 0 until 4) {
                val e = d[r * 4 + c]
                val t = TextView(ctx)
                t.gravity = Gravity.CENTER
                t.textSize = 28f
                t.tag = e
                t.background = ctx.rounded(off, 12)
                t.layoutParams = LinearLayout.LayoutParams(size - ctx.dp(8), size - ctx.dp(8)).apply {
                    setMargins(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
                }
                t.setOnClickListener { flip(t, e) }
                row.addView(t)
            }
            area.addView(row)
        }
    }

    private fun flip(t: TextView, e: String) {
        if (lock || t.text.isNotEmpty()) return
        t.text = e
        t.background = ctx.rounded(Color.WHITE, 12)
        op.add(t)
        if (op.size == 2) {
            mv++
            info.text = "Level $lv  \u00B7  Chaal $mv"
            val x = op[0]
            val y = op[1]
            if (x.tag == y.tag) {
                op.clear(); found++
                if (found == p) {
                    if (lv > best) best = lv
                    info.text = "Level $lv clear! \uD83C\uDF89 ($mv chaal)"
                    lv++
                    later(1400) { round() }
                }
            } else {
                lock = true
                later(700) {
                    x.text = ""; y.text = ""
                    x.background = ctx.rounded(off, 12); y.background = ctx.rounded(off, 12)
                    op.clear(); lock = false
                }
            }
        }
    }
}

class OrdGame(ctx: Context) : Game(ctx, "ord", "Number Order") {
    private var lv = 1
    private val off = Color.parseColor("#C9D8D3")
    private lateinit var info: TextView
    private lateinit var area: LinearLayout

    override fun build(): View {
        val root = col()
        info = ctx.label("", 17f, INK, true)
        info.gravity = Gravity.CENTER
        area = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, ctx.dp(12), 0, 0) }
        root.addView(info); root.addView(area)
        round()
        return root
    }

    private fun round() {
        val n = minOf(25, 3 + lv * 2)
        var nx = 1
        val t0 = System.currentTimeMillis()
        val cols = if (n <= 9) 3 else if (n <= 16) 4 else 5
        val size = minOf(ctx.dp(90), (ctx.resources.displayMetrics.widthPixels - ctx.dp(64)) / cols)
        info.text = "Level $lv: 1 se $n tak order mein tap karo"
        area.removeAllViews()
        var row = LinearLayout(ctx)
        (1..n).shuffled().forEachIndexed { i, v ->
            if (i % cols == 0) { row = LinearLayout(ctx); area.addView(row) }
            val t = TextView(ctx)
            t.text = "$v"; t.textSize = 24f; t.gravity = Gravity.CENTER
            t.setTextColor(INK)
            t.background = ctx.rounded(off, 12)
            t.layoutParams = LinearLayout.LayoutParams(size - ctx.dp(8), size - ctx.dp(8)).apply {
                setMargins(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
            }
            t.setOnClickListener {
                if (v == nx) {
                    t.alpha = 0.25f; t.isEnabled = false; nx++
                    if (nx > n) {
                        if (lv > best) best = lv
                        val s = "%.1f".format((System.currentTimeMillis() - t0) / 1000.0)
                        info.text = "Level $lv clear! ${s}s \uD83C\uDF89"
                        lv++
                        later(1400) { round() }
                    }
                } else {
                    t.background = ctx.rounded(Color.parseColor("#E53935"), 12)
                    later(250) { t.background = ctx.rounded(off, 12) }
                }
            }
            row.addView(t)
        }
    }
}

class TfGame(ctx: Context) : Game(ctx, "tf", "Sahi ya Galat") {
    private var score = 0
    private var truth = true
    private var timer: CountDownTimer? = null
    private lateinit var info: TextView
    private lateinit var q: TextView
    private lateinit var area: LinearLayout

    override fun build(): View {
        val root = col()
        info = ctx.label("", 18f, INK, true)
        q = ctx.label("", 38f, INK, true)
        q.gravity = Gravity.CENTER
        q.setPadding(0, ctx.dp(20), 0, ctx.dp(20))
        area = LinearLayout(ctx)
        root.addView(info); root.addView(q); root.addView(area)
        start()
        return root
    }

    private fun start() {
        score = 0
        ask()
        timer?.cancel()
        timer = object : CountDownTimer(30000, 1000) {
            override fun onTick(m: Long) { info.text = "Score $score   |   ${m / 1000}s" }
            override fun onFinish() {
                if (!alive) return
                if (score > best) best = score
                q.text = "Time up!\nScore: $score"
                area.removeAllViews()
                area.addView(btn("Dobara khelo") { start() }, LinearLayout.LayoutParams(-1, ctx.dp(56)))
            }
        }.start()
    }

    private fun ask() {
        val l = score / 4 + 1
        val a = Random.nextInt(2, 10 + l)
        val b = Random.nextInt(2, 10 + l)
        val mul = Random.nextInt(10) < 4
        val c = if (mul) a * b else a + b
        truth = Random.nextBoolean()
        val shown = if (truth) c else c + (if (Random.nextBoolean()) -1 else 1) * Random.nextInt(1, 4)
        q.text = "$a ${if (mul) "\u00D7" else "+"} $b = $shown"
        area.removeAllViews()
        for (v in listOf(true, false)) {
            val bt = ctx.button(if (v) "\u2705 Sahi" else "\u274C Galat", Color.WHITE, INK) { answer(v) }
            bt.layoutParams = LinearLayout.LayoutParams(0, ctx.dp(64), 1f).apply { setMargins(ctx.dp(4), 0, ctx.dp(4), 0) }
            area.addView(bt)
        }
    }

    private fun answer(v: Boolean) {
        if (v == truth) score++ else score = maxOf(0, score - 1)
        ask()
    }

    override fun stop() { timer?.cancel(); super.stop() }
}

class StroopGame(ctx: Context) : Game(ctx, "stroop", "Rang Pehchano") {
    private val names = listOf("LAL", "NEELA", "HARA", "PEELA")
    private val cols = intArrayOf(Color.parseColor("#E53935"), Color.parseColor("#1E88E5"), Color.parseColor("#2E7D32"), Color.parseColor("#F9A825"))
    private var score = 0
    private var ans = 0
    private var timer: CountDownTimer? = null
    private lateinit var info: TextView
    private lateinit var q: TextView
    private lateinit var area: LinearLayout

    override fun build(): View {
        val root = col()
        info = ctx.label("Shabd nahi, uska RANG batao!", 18f, INK, true)
        q = ctx.label("", 52f, INK, true)
        q.gravity = Gravity.CENTER
        q.setPadding(0, ctx.dp(20), 0, ctx.dp(20))
        area = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(info); root.addView(q); root.addView(area)
        start()
        return root
    }

    private fun start() {
        score = 0
        ask()
        timer?.cancel()
        timer = object : CountDownTimer(30000, 1000) {
            override fun onTick(m: Long) { info.text = "Score $score   |   ${m / 1000}s" }
            override fun onFinish() {
                if (!alive) return
                if (score > best) best = score
                q.setTextColor(INK)
                q.text = "Time up!\nScore: $score"
                area.removeAllViews()
                area.addView(btn("Dobara khelo") { start() })
            }
        }.start()
    }

    private fun ask() {
        val w = Random.nextInt(4)
        ans = Random.nextInt(4)
        q.text = names[w]
        q.setTextColor(cols[ans])
        val order = (0..3).shuffled()
        area.removeAllViews()
        for (r in 0 until 2) {
            val row = LinearLayout(ctx)
            for (c in 0 until 2) {
                val i = order[r * 2 + c]
                val b = ctx.button(names[i], Color.WHITE, INK) { pick(i) }
                b.layoutParams = LinearLayout.LayoutParams(0, ctx.dp(64), 1f).apply { setMargins(ctx.dp(4), ctx.dp(6), ctx.dp(4), 0) }
                row.addView(b)
            }
            area.addView(row)
        }
    }

    private fun pick(i: Int) {
        if (i == ans) score++ else score = maxOf(0, score - 1)
        ask()
    }

    override fun stop() { timer?.cancel(); super.stop() }
}
