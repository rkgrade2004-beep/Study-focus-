package com.studyfocus.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val left = (getSharedPreferences("sf", 0).getLong("end", 0) - System.currentTimeMillis()) / 60000 + 1
        setContentView(TextView(this).apply {
            text = "\uD83D\uDD12\n\nYe locked hai\n$left minute baaki\n\nPadhai karo, phir khulega"
            textSize = 26f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#12332F"))
            setOnClickListener { goHome() }
        })
    }
    override fun onBackPressed() { goHome() }
    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
