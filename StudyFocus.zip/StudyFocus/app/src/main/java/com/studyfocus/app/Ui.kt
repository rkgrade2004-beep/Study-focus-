package com.studyfocus.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

val INK = Color.parseColor("#12332F")
val ACC = Color.parseColor("#E8D44D")
val BG = Color.parseColor("#EEF2EF")
val MUT = Color.parseColor("#5B716D")

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, r: Int = 16) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat()
}

fun Context.label(t: String, size: Float = 16f, color: Int = INK, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size; setTextColor(color)
    if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.button(t: String, bg: Int = INK, fg: Int = Color.WHITE, onClick: () -> Unit) = Button(this).apply {
    text = t; isAllCaps = false; setTextColor(fg); textSize = 16f
    background = rounded(bg, 14)
    layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
    setOnClickListener { onClick() }
}

fun Context.card(vararg views: View) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(Color.WHITE, 18)
    setPadding(dp(16), dp(14), dp(16), dp(14))
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    views.forEach { addView(it) }
}

fun Context.grad(c1: Int, c2: Int, r: Int = 20) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
    cornerRadius = dp(r).toFloat()
}
