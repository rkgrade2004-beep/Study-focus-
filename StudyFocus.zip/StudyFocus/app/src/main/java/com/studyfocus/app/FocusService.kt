package com.studyfocus.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

val DEFAULT_KW = listOf("pw", "wallah", "up board", "upboard", "board", "class 12", "class 11", "class 10", "12th", "11th", "10th",
    "batch", "lecture", "ncert", "jee", "neet", "cbse", "study", "academy", "classes", "vedantu", "unacademy", "khan academy",
    "byju", "doubtnut", "magnet brains", "studyiq", "apni kaksha", "learnohub", "eduncle", "toppr", "physics", "chemistry",
    "maths", "biology", "chapter", "revision", "\u0915\u0915\u094D\u0937\u093E", "\u092C\u094B\u0930\u094D\u0921", "\u092A\u0922\u093C\u093E\u0908")

class FocusService : AccessibilityService() {
    private var kwSig = ""
    private var kwRe = listOf<Regex>()

    private fun matchers(extra: Set<String>): List<Regex> {
        val sig = extra.sorted().joinToString("|")
        if (sig != kwSig) {
            kwSig = sig
            kwRe = (DEFAULT_KW + extra.map { it.lowercase().trim() }.filter { it.isNotEmpty() }).map { k ->
                if (k.all { it.code < 128 }) Regex("(?<![a-z0-9])" + Regex.escape(k) + "(?![a-z0-9])")
                else Regex(Regex.escape(k))
            }
        }
        return kwRe
    }
    private val strict = setOf("com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller", "com.samsung.android.packageinstaller", "com.android.vending", "com.miui.securitycenter")
    private val yt = "com.google.android.youtube"
    private var last = 0L
    private var editable = false
    private var okUntil = 0L
    private val known = HashSet<String>()

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName || pkg.startsWith("com.android.systemui")) return
        val sp = getSharedPreferences("sf", 0)
        if (System.currentTimeMillis() >= sp.getLong("end", 0)) return

        val blocked = sp.getStringSet("apps", emptySet())!!
        var block = pkg in blocked || pkg in strict
        var isYt = false
        if (!block && pkg == yt) {
            val chans = sp.getStringSet("chans", emptySet())!!.map { it.substringBefore("|").lowercase() }
            if (chans.isNotEmpty()) {
                isYt = true
                val texts = ArrayList<String>()
                editable = false
                collect(rootInActiveWindow, texts, 0)
                val all = texts.joinToString(" ").lowercase()
                val now = System.currentTimeMillis()
                val hasChannel = chans.any { all.contains(it) } || matchers(sp.getStringSet("kwx", emptySet())!!).any { it.containsMatchIn(all) }
                if (hasChannel) {
                    known.clear()
                    known.addAll(texts.filter { it.length >= 15 }.take(60))
                }
                val sameVideo = texts.any { it.length >= 15 && it in known }
                val allowed = all.isBlank() || editable || hasChannel || sameVideo
                if (allowed) okUntil = now + 60000
                block = !allowed && now > okUntil
            }
        }
        if (block) {
            val now = System.currentTimeMillis()
            if (now - last > 1200) {
                last = now
                if (isYt) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    Toast.makeText(this, "Study channel nahi hai, wapas", Toast.LENGTH_SHORT).show()
                } else {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    Toast.makeText(this, "Focus chal raha hai \uD83D\uDCDA", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, d: Int) {
        if (n == null || d > 25) return
        if (n.isEditable) editable = true
        n.text?.let { out.add(it.toString()) }
        n.contentDescription?.let { out.add(it.toString()) }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }

    override fun onInterrupt() {}
}
