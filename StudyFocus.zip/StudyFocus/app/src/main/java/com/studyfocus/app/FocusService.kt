package com.studyfocus.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Intent

class FocusService : AccessibilityService() {
    private val strict = setOf("com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller", "com.samsung.android.packageinstaller", "com.android.vending", "com.miui.securitycenter")
    private var last = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName || pkg.startsWith("com.android.systemui")) return
        val sp = getSharedPreferences("sf", 0)
        if (System.currentTimeMillis() >= sp.getLong("end", 0)) return

        val blocked = sp.getStringSet("apps", emptySet())!!
        var block = pkg in blocked || pkg in strict
        if (!block && pkg == "com.google.android.youtube") {
            val chans = sp.getStringSet("chans", emptySet())!!.map { it.substringBefore("|").lowercase() }
            if (chans.isNotEmpty()) {
                val sb = StringBuilder()
                collect(rootInActiveWindow, sb, 0)
                val t = sb.toString().lowercase()
                if (t.isNotBlank()) block = chans.none { t.contains(it) }
            }
        }
        if (block) {
            val now = System.currentTimeMillis()
            if (now - last > 800) {
                last = now
                startActivity(Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            }
        }
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder, d: Int) {
        if (n == null || d > 25) return
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until n.childCount) collect(n.getChild(i), sb, d + 1)
    }

    override fun onInterrupt() {}
}
